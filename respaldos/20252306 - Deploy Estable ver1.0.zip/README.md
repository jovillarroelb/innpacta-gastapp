# control_gastos
 App personal para el control de gastos personales.
